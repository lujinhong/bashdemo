#!/bin/bash

#script:
#	SpecialVariable.bash
#author:
#	lujinhong
#purpose
#	Test servral special variables.
#history
#	2012.12.06 v1.0, learned from Linux Shell Scripting Cookbook.

echo $@
echo $*
echo $1
echo $?
